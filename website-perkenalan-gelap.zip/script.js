const text = "👋 Halo! Saya [Nama Anda]";
let index = 0;
const speed = 80;

function typeWriter() {
  if (index < text.length) {
    document.querySelector(".typewriter-text").innerHTML += text.charAt(index);
    index++;
    setTimeout(typeWriter, speed);
  }
}

document.addEventListener("DOMContentLoaded", typeWriter);
